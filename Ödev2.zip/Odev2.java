package com.example.javadersleri.Nesne_tabanli;
//Umut Eren Kaplan
public class Odev2 {
    public double Soru1(double Km){
        double Mile = Km * 0.621;
        return Mile;
    }
    public void Soru2(double x, double y){

        System.out.println("Alan hesabı :"+(x*y));
    }
    public long Soru3(int sayi){

            if (sayi <= 1) {
                return 1;
            } else {
                return sayi * Soru3(sayi - 1);
            }
    }
    public void Soru4(String kelime){
        int toplamKarakter = 0;
        char temp;
        for(int i= 0; i <kelime.length();i++){
           temp = kelime.charAt(i);
           if(temp =='e' || temp=='E'){
               toplamKarakter++;
           }
        }
        System.out.println("e karakteri "+toplamKarakter+" kez kelimede var.");
    }
    public double Soru5(double kenarSayisi){
        double icAci = ((kenarSayisi-2)*180)/kenarSayisi;
        return icAci;
    }
    public void Soru6(int gun){
        int birGundekiCalismaSaati = 8;
        int sabitSaatUcret = 40;
        int ekSaatUcret = 80;
        int normalCalismaSaati = 150;
        int ekCalismaSaati;
        int toplam;
        if(birGundekiCalismaSaati * gun  <= normalCalismaSaati){
            toplam = (birGundekiCalismaSaati*sabitSaatUcret)*gun;
            System.out.println("Toplam ücretiniz" + toplam +"Tl'dir");
        }
        else if(birGundekiCalismaSaati * gun  >= normalCalismaSaati){
            ekCalismaSaati = ((birGundekiCalismaSaati*gun)-normalCalismaSaati);
            toplam = (normalCalismaSaati*sabitSaatUcret)+(ekCalismaSaati*ekSaatUcret);
            System.out.println("Toplam ücretiniz "+toplam+"TL'dir ");
        }
    }
    public  int Soru7(int saat){
        int sabitUcret = 50;
        int ekUcret = 10;
        int toplam = 0;
        if (saat  == 1 ){
            return sabitUcret;
        }
        else if (saat > 1) {
            toplam=((saat-1)*ekUcret)+sabitUcret;

        }
        return  toplam;
}}
