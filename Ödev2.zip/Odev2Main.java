package com.example.javadersleri.Nesne_tabanli;
//Umut Eren Kaplan
public class Odev2Main {
    public static void main(String[] args) {
        Odev2 o = new Odev2();
        double sonuc1 = o.Soru1(220);
        System.out.println("Mile:  " + sonuc1);

        o.Soru2(12,16);

        long sonuc3 = o.Soru3(9);
        System.out.println("Faktöriyel: " + sonuc3);

        o.Soru4("selimeren");

        double sonuc5 = o.Soru5(5);
        System.out.println("bir iç açı toplamı: " + sonuc5);

        o.Soru6(25);
        int sonuc7 = o.Soru7(6);
        System.out.println("Otopark ücretiniz" + sonuc7+ "Tl'dir");


    }
}
