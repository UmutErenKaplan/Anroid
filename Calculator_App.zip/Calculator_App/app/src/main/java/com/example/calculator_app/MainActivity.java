package com.example.calculator_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button_C,button_Open,button_Close,button_Div;
    Button button_Seven,button_Eight,button_Nine,button_Multi;
    Button button_Four,button_Five,button_Six,button_Minus;
    Button button_One,button_Two,button_Three,button_Plus;
    Button button_AC,button_Zero,button_Dot,button_Equal;

    TextView result,solution;

    float valueOne,valueTwo;

    boolean plus,minus,div,multi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.result);
        solution = findViewById(R.id.solution);



        button_C =(Button) findViewById(R.id.button_C);
        button_Open =(Button) findViewById(R.id.button_Open);
        button_Close =(Button) findViewById(R.id.button_Close);
        button_Div =(Button) findViewById(R.id.button_Div);
        button_Seven =(Button) findViewById(R.id.button_Seven);
        button_Eight =(Button) findViewById(R.id.button_Eight);
        button_Nine =(Button) findViewById(R.id.button_Nine);
        button_Multi =(Button) findViewById(R.id.button_Multi);
        button_Four =(Button) findViewById(R.id.button_Four);
        button_Five =(Button) findViewById(R.id.button_Five);
        button_Six =(Button) findViewById(R.id.button_Six);
        button_Minus =(Button) findViewById(R.id.button_Minus);
        button_One =(Button) findViewById(R.id.button_One);
        button_Two =(Button) findViewById(R.id.button_Two);
        button_Three =(Button) findViewById(R.id.button_Three);
        button_Plus =(Button) findViewById(R.id.button_Plus);
        button_AC =(Button) findViewById(R.id.button_AC);
        button_Zero =(Button) findViewById(R.id.button_Zero);
        button_Dot =(Button) findViewById(R.id.button_Dot);
        button_Equal =(Button) findViewById(R.id.button_Equal);

        button_One.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"1");
                solution.setText(result.getText());
            }
        });

        button_Two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"2");
                solution.setText(result.getText());
            }
        });

        button_Three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"3");
                solution.setText(result.getText());
            }
        });

        button_Four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"4");
                solution.setText(result.getText());
            }
        });
        button_Five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"5");
                solution.setText(result.getText());
            }
        });
        button_Six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"6");
                solution.setText(result.getText());
            }
        });

        button_Seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"7");
                solution.setText(result.getText());
            }
        });
        button_Eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"8");
                solution.setText(result.getText());
            }
        });
        button_Nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"9");
                solution.setText(result.getText());
            }
        });
        button_Zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+"0");
                solution.setText(result.getText());
            }
        });

        button_Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(result.getText()+".");
                solution.setText(result.getText());
            }
        });
        button_AC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText("");
            }
        });

        button_Plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(result == null){
                    result.setText("");
                }
                else{
                    valueOne=Float.parseFloat(result.getText()+"");
                    plus =true;
                    result.setText(null);
                }
            }
        });

        button_Minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    valueOne=Float.parseFloat(result.getText()+"");
                    minus = true;
                    result.setText(null);

            }
        });

        button_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  valueOne = Float.parseFloat(result.getText()+"");
                    div = true;
                    result.setText(null);

            }
        });
        button_Multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueOne = Float.parseFloat(result.getText()+"");
                multi = true;
                result.setText(null);
            }
        });
        button_Equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueTwo = Float.parseFloat(result.getText()+"");
                if(plus == true){
                    result.setText(valueOne+valueTwo+"");
                    solution.setText(valueOne+"+"+valueTwo);
                    plus = false;
                }
                if(minus == true){
                    result.setText(valueOne-valueTwo+"");
                    solution.setText(valueOne+"-"+valueTwo);
                    minus=false;
                }
                if(div == true){
                    result.setText(valueOne/valueTwo+"");
                    solution.setText(valueOne+"/"+valueTwo);
                    div=false;
                }
                if(multi== true){
                    result.setText(valueOne*valueTwo+"");
                    solution.setText(valueOne+"*"+valueTwo);
                    multi=false;
                }
            }
        });



    }
}